# Security Policy

## Reporting a Vulnerability
If you discover a security issue, please **do not open a public GitHub issue**.

Instead, contact us at: **security@atvisai.in**

We will acknowledge receipt within 48 hours and work on a fix as soon as possible.

## Supported Versions
We only provide security updates for the latest release of this project.
