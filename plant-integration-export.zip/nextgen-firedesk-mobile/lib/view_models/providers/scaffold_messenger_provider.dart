import 'package:flutter/material.dart';

class ScaffoldMessengerProvider extends ChangeNotifier{
  final GlobalKey<ScaffoldMessengerState> scaffoldMessengerKey = GlobalKey<ScaffoldMessengerState>();
}