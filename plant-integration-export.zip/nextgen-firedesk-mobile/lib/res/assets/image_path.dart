class AssetImagepath{
   static const String assetImagePath = "assets/images/";
}