class Font{
  static const String poppinsFont = "Poppins";
}