import 'package:flutter/foundation.dart';

debugPrint(String data) {
  if (kDebugMode) {
    print(data);
  }
}
